// --- CADASTRO ---
async function cadastrar(event) {
    event.preventDefault();  // Previne o comportamento padrão do formulário

    // Co   leta os dados do formulário
    const name = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const cpf = document.getElementById('cpf').value;
    const cor = document.getElementById('cor').value;
    const placa = document.getElementById('placa').value;
    const marca = document.getElementById('marca').value;
    const vaga = document.getElementById('vaga').value;
    const pass = document.getElementById('senha').value;

    // Verifica se os campos estão preenchidos
    if (!name || !email || !cpf || !cor || !placa || !marca || !vaga || !pass) {
        alert("Todos os campos devem ser preenchidos!");
        return;
    }

    // Cria o objeto com os dados a serem enviados para a API
    const data = { name, email, cpf, cor, marca, placa, vaga, pass};

    try {
        // Realiza a requisição POST para a API
        const response = await fetch('http://localhost:3005/usuario/cadastrar', {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        });

        // Converte a resposta em JSON
        const result = await response.json();

        // Lida com a resposta
        if (response.ok) {
            alert(result.message);

            window.location.href= "../pgPrincipal/principal.html";
        } else {
            alert(`Erro: ${result.message}`);
        }
    } catch (error) {
        console.error('Erro durante o cadastro:', error);
        alert("Ocorreu um erro ao tentar realizar o cadastro.");
    }
}


// --- LOGIN ---  

async function logar(event) {
    event.preventDefault();  // Previne o comportamento padrão do formulário

    // Coleta os dados do formulário
    const email = document.getElementById('email').value;
    const pass = document.getElementById('pass').value;

    // Verifica se os campos estão preenchidos
    if (!email || !pass) {
        alert("Todos os campos devem ser preenchidos!");
        return;
    }

    // Cria o objeto com os dados a serem enviados para a API
    const data = { email, pass };

    try {
        const response = await fetch("http://localhost:3005/login", {
            method: 'POST',
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(data),
        });

        let results = await response.json();

        if (results.success) {
            alert(results.message);

            // Armazena os dados do usuário no localStorage para persistir o login
            let userData = results.data;
            localStorage.setItem('Informacoes', JSON.stringify(userData));

            window.location.href= "../pgPrincipal/principal.html";
            
        } else {
            alert(results.message);
        }
    } catch (error) {
        console.error("Erro ao realizar login:", error);
        alert("Erro ao realizar login. Tente novamente mais tarde.");
    }
}
