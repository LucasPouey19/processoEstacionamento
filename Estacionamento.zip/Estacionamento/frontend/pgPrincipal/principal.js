document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".checkBox").forEach((vaga, index) => {
        const numero = document.createElement("p");
        numero.textContent = `${index + 1}`;
        numero.classList.add("numero-vaga"); // Adiciona uma classe para fácil manipulação
        vaga.prepend(numero);
    });

    document.querySelectorAll(".checkBox input[type=checkbox]").forEach(checkbox => {
        checkbox.addEventListener("change", function () {
            const label = this.closest(".checkBox");
            const button = label.closest(".button"); 
            const numero = label.querySelector(".numero-vaga"); // Seleciona o número

            if (this.checked) {
                label.classList.add("ocupada");
                button.classList.add("ocupada");
                numero.classList.add("ocupada"); // Adiciona a classe ao número
            } else {
                label.classList.remove("ocupada");
                button.classList.remove("ocupada");
                numero.classList.remove("ocupada"); // Remove a classe do número
            }
        });
    });
});
