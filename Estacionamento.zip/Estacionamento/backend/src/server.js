const mysql = require ('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Lucas@19',
    database: 'srclub'
});

connection.connect((err) =>{
    if(err) {
        throw err;
    }   else {
        console.log('FALA COMIGO BEBE')
    }
});

module.exports = connection;

//  --- Server ---

const express = require("express");
const cors = require("cors");
// const connection = require('./db_config'); 
// const multer = require('multer');

const port = 3005;


const app = express();

app.use(cors());
app.use(express.json());

app.listen(port, () => console.log(`Vamo se encontra no quarto do motel: ${port}`));

// --- Cadastro ---

// Rota POST /usuario/cadastrar
app.post('/usuario/cadastrar', async (request, response) => {
    const { name, email, cpf , cor, marca, placa, vaga, pass  } = request.body; 

    // Query para inserir os dados
    let query = "INSERT INTO users(name, email, cpf, color, brand, plate, tape, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    // Executar a query no banco de dados
    connection.query(query, [name, email, cpf, cor, marca, placa, vaga, pass], (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao cadastrar usuário",
                error: err
            });
        }
        response.status(201).json({
            success: true,
            message: "Usuário cadastrado com sucesso",
            data: results
        });
    });
});

// --- Login ---

app.post('/login', (request, response) => {
    const email = request.body.email;
    const pass = request.body.pass;

    // Verifica se os campos foram enviados corretamente
    if (!email || !pass) {
        return response.status(400).json({
            success: false,
            message: "Campos de email e senha são obrigatórios.",
        });
    }

    // Cria a query SQL para buscar o usuário
    let query = "SELECT id, name, email, password FROM users WHERE email = ?";
    let params = [email];  // Adiciona o email nos parâmetros

    connection.query(query, params, (err, results) => {
        if (err) {
            console.error("Erro ao consultar o banco de dados:", err);
            return response.status(500).json({
                success: false,
                message: "Erro no servidor.",
            });
        }

        // Verifica se o email existe no banco
        if (results.length > 0) {
            const senhaDigitada = pass;
            const senhaBanco = results[0].password;

            // Compara a senha enviada com a senha armazenada no banco de dados
            if (senhaBanco === senhaDigitada) {
                return response.status(200).json({
                    success: true,
                    message: "Login realizado com sucesso!",
                    data: results[0],  // Envia os dados do usuário (menos a senha)
                });
            } else {
                return response.status(400).json({
                    success: false,
                    message: "Credenciais inválidas.",
                });
            }
        } else {
            return response.status(400).json({
                success: false,
                message: "Credenciais inválidas.",
            });
        }
    });
});
// Marcar uma vaga
app.post('/ocupar-vaga', (req, res) => {
    const { usuario_id, vaga_id } = req.body;

    // Verifica se o usuário já tem uma vaga ocupada
    db.query('SELECT id FROM vagas WHERE usuario_id = ?', [usuario_id], (err, result) => {
        if (err) return res.status(500).json({ error: err });

        if (result.length > 0) {
            return res.status(400).json({ message: "Você já tem uma vaga ocupada. Desocupe antes de marcar outra." });
        }

        // Se não tem vaga, ocupa a nova
        db.query('UPDATE vagas SET ocupada = TRUE, usuario_id = ? WHERE id = ? AND ocupada = FALSE', 
        [usuario_id, vaga_id], (err, result) => {
            if (err) return res.status(500).json({ error: err });

            if (result.affectedRows === 0) {
                return res.status(400).json({ message: "Vaga já ocupada ou não existe." });
            }

            res.json({ message: "Vaga ocupada com sucesso!" });
        });
    });
});

// Desocupar uma vaga
app.post('/desocupar-vaga', (req, res) => {
    const { usuario_id } = req.body;

    db.query('UPDATE vagas SET ocupada = FALSE, usuario_id = NULL WHERE usuario_id = ?', 
    [usuario_id], (err, result) => {
        if (err) return res.status(500).json({ error: err });

        if (result.affectedRows === 0) {
            return res.status(400).json({ message: "Nenhuma vaga encontrada para desocupar." });
        }

        res.json({ message: "Vaga desocupada com sucesso!" });
    });
});