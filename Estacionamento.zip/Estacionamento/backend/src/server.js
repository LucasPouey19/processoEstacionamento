const mysql = require ('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Lucas@19',
    database: 'srclub'
});

connection.connect((err) =>{
    if(err) {
        throw err;
    }   else {
        console.log('FALA COMIGO BEBE')
    }
});

module.exports = connection;

//  --- Server ---

const express = require("express");
const cors = require("cors");
// const connection = require('./db_config'); 
// const multer = require('multer');

const port = 3005;


const app = express();

app.use(cors());
app.use(express.json());

app.listen(port, () => console.log(`Vamo se encontra no quarto do motel: ${port}`));

// --- Cadastro ---

// Rota POST /usuario/cadastrar
app.post('/usuario/cadastrar', async (request, response) => {
    const { name, email, cpf , cor, marca, placa, vaga, pass  } = request.body; 

    // Query para inserir os dados
    let query = "INSERT INTO users(name, email, cpf, color, brand, plate, tape, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    // Executar a query no banco de dados
    connection.query(query, [name, email, cpf, cor, marca, placa, vaga, pass], (err, results) => {
        if (err) {
            return response.status(400).json({
                success: false,
                message: "Erro ao cadastrar usuário",
                error: err
            });
        }
        response.status(201).json({
            success: true,
            message: "Usuário cadastrado com sucesso",
            data: results
        });
    });
});

// --- Login ---

app.post('/login', (request, response) => {
    const email = request.body.email;
    const pass = request.body.pass;

    // Verifica se os campos foram enviados corretamente
    if (!email || !pass) {
        return response.status(400).json({
            success: false,
            message: "Campos de email e senha são obrigatórios.",
        });
    }

    // Cria a query SQL para buscar o usuário
    let query = "SELECT id, name, email, password FROM users WHERE email = ?";
    let params = [email];  // Adiciona o email nos parâmetros

    connection.query(query, params, (err, results) => {
        if (err) {
            console.error("Erro ao consultar o banco de dados:", err);
            return response.status(500).json({
                success: false,
                message: "Erro no servidor.",
            });
        }

        // Verifica se o email existe no banco
        if (results.length > 0) {
            const senhaDigitada = pass;
            const senhaBanco = results[0].password;

            // Compara a senha enviada com a senha armazenada no banco de dados
            if (senhaBanco === senhaDigitada) {
                return response.status(200).json({
                    success: true,
                    message: "Login realizado com sucesso!",
                    data: results[0],  // Envia os dados do usuário (menos a senha)
                });
            } else {
                return response.status(400).json({
                    success: false,
                    message: "Credenciais inválidas.",
                });
            }
        } else {
            return response.status(400).json({
                success: false,
                message: "Credenciais inválidas.",
            });
        }
    });
});

app.get('/usuario/listar', (request, response) => {
    const query = "select * from users";

    connection.query(query, (err, results) => {
        if (results) {
            response
                .status(200)
                .json({
                    success: true,
                    message: "Sucesso",
                    data: results
                })
        } else {
            response
                .status(403)
                .json({
                    success: false,
                    message: "Sem sucesso",
                    data: err
                })
        }
    })
})
