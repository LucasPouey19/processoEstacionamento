create database srclub;
use srclub;
 
create table users(
    id int not null auto_increment primary key,
    name varchar(55) not null,
    email varchar(55) unique ,
    cpf varchar(11),
    color varchar(55),
    brand varchar(55),
    plate varchar(7),
    tape enum('preferencial', 'normal'),
    password varchar(55)
);
 
create table vagas(
    id int primary key auto_increment,
	numero int unique not null,
    ocupada boolean default false,
    user_id int null,
    foreign key (user_id) references users(id) on delete set null
);

